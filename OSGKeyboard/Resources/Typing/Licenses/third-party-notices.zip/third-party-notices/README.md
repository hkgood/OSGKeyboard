# Third-Party Dependency Notices

This directory contains vcpkg-provided license texts for third-party dependency
code that may be linked into the librime XCFramework binary artifacts.

The release also includes LICENSE.txt for this packaging wrapper and
THIRD_PARTY_NOTICES.md for the upstream librime notice.
